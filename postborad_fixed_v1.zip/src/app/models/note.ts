export class Note {
    key: string;
    author: string;
    content: string;
    createdDate: string;
    constructor() {
        this.content = '';
    }
}
